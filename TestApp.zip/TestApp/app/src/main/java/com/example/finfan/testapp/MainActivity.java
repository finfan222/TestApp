package com.example.finfan.testapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        result = (EditText) findViewById(R.id.result);
    }

    private enum EOperType {
        ADD("+"),
        SUB("-"),
        DIV("*"),
        MUL("/");
        private final String opname;
        private EOperType(String n) {
            opname = n;
        }
    }

    private EOperType opType;

    public void onButtonClick_Add(View view) {
        Button btn = (Button) findViewById(R.id.btn_add);
        applyOperation(EOperType.ADD);
    }

    public void onButtonClick_Sub(View view) {
        Button btn = (Button) findViewById(R.id.btn_sub);
        updateCursorPos();
    }

    public void onButtonClick_Div(View view) {
        Button btn = (Button) findViewById(R.id.btn_div);
        updateCursorPos();
    }

    public void onButtonClick_Mul(View view) {
        Button btn = (Button) findViewById(R.id.btn_mul);
        updateCursorPos();
    }

    public void onButtonClick_Equal(View view) {
        Button btn = (Button) findViewById(R.id.btn_equal);
        equalize();
        updateCursorPos();
    }

    private void equalize() {
       final String[] splitter = result.getText().toString().split(opType.opname);
        double value1 = Double.parseDouble(splitter[0]);
        double value2 = Double.parseDouble(splitter[1]);
        String valuePrint;
        switch(opType) {
            case ADD:
                valuePrint = String.valueOf(value1 + value2);
                break;
        }

        updateCursorPos();
    }

    private void applyOperation(EOperType opType) {
        if(this.opType != null) {
            // calculate the values by given operate type
            equalize();
            this.opType = null;
            result.setText("");
            updateCursorPos();
            return;
        }

        this.opType = opType;
        result.setText(result.getText() + this.opType.opname);
        updateCursorPos();
    }

    private void updateCursorPos() {
        result.setSelection(result.getText().length());
    }

}
